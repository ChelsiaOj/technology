<?php
include("sql.php");
$id=$_GET['n'];
//echo $id;
mysqli_query($con,"delete from `tbl_user` where id='$id'");
header("location:/ssql/view.php");
?>
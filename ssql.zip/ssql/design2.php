<?php
include("sql.php");
if(isset($_POST['btn']))
{
	$name=$_POST['name'];
	$addr=$_POST['addres'];
	$phone=$_POST['phone'];
	echo "$name";
	echo "$addr";
	echo "$phone";
	
}
?>

<?php

$con=mysqli_connect("localhost","root","","sample");
if(!$con)
{
echo "not connected";
}

?>
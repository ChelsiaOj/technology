<?php
include("sql.php");
$result=mysqli_query($con,"select * from `tbl_user`");
//$row=mysqli_fetch_array($result);

?>
<html>
<table border=1 width="30%">
<th>Id</th><th>Name</th><th>Address</th><th>Phone</th><th>Edit</th><th>Delete</th>

<?php
while($row=mysqli_fetch_array($result))
{
	
?>
<tr><td><?php echo $row['id'];?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['phone'];?></td>
<td><a href="edit.php?i=<?php echo $row['id'];?>">edit</td>
<td><a href="delete.php?n=<?php echo $row['id'];?>">delete</td>

</tr>

<?php
}
?>
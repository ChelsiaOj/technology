<?php

include("sql.php");
$id=$_GET['i'];
//echo $id;
$result=mysqli_query($con,"select * from `tbl_user` where id='$id'");
$row=mysqli_fetch_array($result);
?>
<html>

<form action="#" method="POST">
<table>
<tr><td>Name:</td><td><input type="text" name="txtname" value="<?php echo $row['name'];?>"> </td></tr>
<tr><td>Address:</td><td><input type="text"  name="txtadd" value="<?php echo $row['address'];?>"> </td></tr>
<tr><td>Phone:</td><td><input type="text" name="txtph" value="<?php echo $row['phone'];?>"></td></tr> 
<tr><td>
<input type="submit" value="update" name="btn"></td></tr> 

</table>
</form>
<?php
if(isset($_POST['btn']))
{
$name=$_POST['txtname'];
	$addr=$_POST['txtadd'];
	$phone=$_POST['txtph'];
	
$query="UPDATE `tbl_user` SET `name`='$name',`address`='$addr',`phone`='$phone' WHERE id='$id'";
mysqli_query($con,$query);
header("location:/ssql/view.php");
//header("location:/ssql/edit.php");

}
?>
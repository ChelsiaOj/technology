
<?php


require_once("dbcontroller.php");
$db_handle = new DBController();
$query1 ="SELECT * FROM tbl_country";
$results = $db_handle->runQuery($query1);
?>



<html>
<head>
	<title>Country</title>
	<script src="jquery-3.2.1.min.js" type="text/javascript"></script>
	
	<script>
function getState(val) {
	$.ajax({
	type: "POST",
	url: "getState.php",
	data:'country_id='+val,
	success: function(data){
		$("#state-list").html(data);
		getCity();
	}
	});
}


function getCity(val) {
	$.ajax({
	type: "POST",
	url: "getCity.php",
	data:'state_id='+val,
	success: function(data){
		$("#city-list").html(data);
	}
	});
}

</script>


</head>

<body>
<br><br><br>
	<table><form action="#" method="POST">
	<tr>
	<td>Name</td>
	<td><input type="text" name="name"></td>
	</tr>

	<tr>
	<td>Country:</td>
	<td><select name="country" id="country-list" class="demoInputBox" onChange="getState(this.value);">
                <option value disabled selected>Select Country</option>
                <?php
		foreach($results as $country) {
		?>
                <option value="<?php echo $country["cid"]; ?>"><?php echo $country["cname"]; ?></option>
                <?php
		}
		?></select>
	</td>
	</tr>
	<tr>
	<td>State:</td>
	<td><select name="state" id="state-list" class="demoInputBox" onChange="getCity(this.value);">
                <option value="">Select State</option>
            </select></td>
	</tr>
	<tr>
	<td>District:</td>
	<td><select name="city" id="city-list" class="demoInputBox">
                <option value="">Select District</option>
            </select></td>
	</tr>
	</table>
	<br>
	<input type="submit" name=" btn" value="Submit"><br>
		</form>
		</body>
</html>


	<?php
if(isset($_POST['btn']))
{
	$cname=$_POST['name'];
$country=$_POST['country'];
	$state=$_POST['state'];
	$district=$_POST['city'];
	
$query="INSERT INTO `tbl_user`(`name`,`country`, `state`,`district`) VALUES ('$cname','$country','$state','$district')";
$db_handle->runQuery($query);
}
?>
       




<?php
include("sql.php");
?>
<html>
<form action="#" method="POST">
<table>
<tr><td>Name:</td><td><input type="text" name="name"></td></tr>
<tr><td>Address:</td><td><input type="text" name="addres"></td></tr>
<tr><td>Phone:</td><td><input type="text" name="phone"></td></tr>
<tr><td></td><td><input type="submit" name="btn" value="ok"></td></tr>
<table>
</
</html>
<?php
if(isset($_POST['btn']))
{
$name=$_POST['name'];
	$addr=$_POST['addres'];
	$phone=$_POST['phone'];
	
$query="INSERT INTO `tbl_user`(`name`, `address`, `phone`) VALUES ('$name','$addr','$phone')";
mysqli_query($con,$query);
}




?>